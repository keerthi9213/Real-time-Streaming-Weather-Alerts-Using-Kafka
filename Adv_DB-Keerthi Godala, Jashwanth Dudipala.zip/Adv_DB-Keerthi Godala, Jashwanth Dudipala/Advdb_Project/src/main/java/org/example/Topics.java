package org.example;
import java.util.Properties;
import java.util.Arrays;
import java.util.ArrayList;
import java.util.concurrent.ExecutionException;

import org.apache.kafka.clients.admin.AdminClient;
import org.apache.kafka.common.config.TopicConfig;
import org.apache.kafka.common.serialization.StringSerializer;
import org.apache.kafka.clients.admin.NewTopic;
import org.apache.kafka.common.errors.TopicExistsException;
public class Topics {

    public static void main(String[] args) throws InterruptedException, ExecutionException {

        //String bootstrapServers = "localhost:9092";
        String bootstrapServers = "172.20.89.232:9092";
        Properties props = new Properties();
        props.put("bootstrap.servers", bootstrapServers);

        AdminClient adminClient = AdminClient.create(props);

        // Define the topic names and partitions
        NewTopic topic1 = new NewTopic("Weather", 1, (short) 1);
        NewTopic topic2 = new NewTopic("Alerts", 1, (short) 1);
        NewTopic topic3 = new NewTopic("Sample", 1, (short) 1);

        // Create the kafka topics
        try {
            adminClient.createTopics(Arrays.asList(topic1, topic2, topic3)).all().get();
            System.out.println("Kafka Topics Created!");
        } catch (ExecutionException e) {
            if (e.getCause() instanceof TopicExistsException) {
                System.out.println("The Topics which you are creating already exists.");
            } else {
                throw e;
            }
        }

        // admin closes
        adminClient.close();
    }
}
