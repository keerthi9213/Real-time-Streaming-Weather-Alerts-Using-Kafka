package org.example;

import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.common.serialization.StringDeserializer;

import java.time.Duration;
import java.util.Arrays;
import java.util.Date;
import java.util.Properties;

public class Consumer {

    public static void main(String[] args) {
        String bootstrapServers = "172.20.89.232:9092";
        String groupId = "my-group-id";
        String[] topics = {"Weather", "Alerts", "Sample"};


        try (KafkaConsumer<String, String> consumer = createKafkaConsumer(bootstrapServers, groupId)) {
            consumer.subscribe(Arrays.asList(topics));

            while (true) {

                ConsumerRecords<String, String> records = consumer.poll(Duration.ofMillis(100));
                for (ConsumerRecord<String, String> record : records) {
                    System.out.printf("topic = %s, offset = %d, key = %s, value = %s%n",
                            record.topic(), record.offset(), record.key(), record.value());
                    //System.out.printf("Received message with key: %s, value: %s, from topic: %s, partition: %d, at offset: %d, timestamp: %s%n",
                            //record.key(), record.value(), record.topic(), record.partition(), record.offset(), new Date(record.timestamp()));

                }
                // Commit offsets
                consumer.commitAsync();
            }
        } catch (Exception e) {
            e.printStackTrace(); // handle exceptions
        }

    }

    private static KafkaConsumer<String, String> createKafkaConsumer(String bootstrapServers, String groupId) {
        Properties props = new Properties();
        props.setProperty(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapServers);
        props.setProperty(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class.getName());
        props.setProperty(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class.getName());
        props.setProperty(ConsumerConfig.GROUP_ID_CONFIG, groupId);
        props.setProperty(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest");
        props.setProperty(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, "true");

        return new KafkaConsumer<>(props);
    }
}
