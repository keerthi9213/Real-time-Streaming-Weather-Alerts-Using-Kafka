package org.example;

import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;
import java.sql.*;
import java.util.Properties;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.common.serialization.StringDeserializer;
import java.time.Duration;
import java.util.Arrays;
import java.util.Properties;


public class Producer {
    public static void main(String[] args) throws IOException {
        Logger logger =LoggerFactory.getLogger(Producer.class.getName());
        String bootstrapServer = "172.20.89.232:9092";


        Properties props = new Properties();
        props.put("bootstrap.servers", bootstrapServer);
        props.put("acks", "all");
        props.put("retries", 0);
        props.put("batch.size", 32768);
        props.put("linger.ms", 5);
        props.put("buffer.memory", 67108864);
        props.put("key.serializer", "org.apache.kafka.common.serialization.StringSerializer");
        props.put("value.serializer", "org.apache.kafka.common.serialization.StringSerializer");


        KafkaProducer<String, String> producer = new KafkaProducer<>(props);
        logger.info("Creating connection to MYSQL Database");
        System.out.println("Creating Connection to MYSQL Database:");
        System.out.println("Connection Success!");


        try {
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/adv_db", "root", "root");
            Statement statement = connection.createStatement();
            ResultSet rs = statement.executeQuery("select * from WeatherAlerts");
            //String query = "SELECT * FROM WeatherAlerts";
            //ResultSet resultSet1 = stmt.executeQuery(query);
            while (rs.next()) {
                String key = rs.getString("alert_timestamp");
                String value = rs.getString("alert_message");
                if (value.contains("Weather")){
                    // Kafka record creation
                    ProducerRecord<String, String> record1 = new ProducerRecord<>("Weather",key ,value);
                    // Send the record to Kafka
                    producer.send(record1);
                } else if (value.contains("Alerts")){
                    ProducerRecord<String, String> record2 = new ProducerRecord<>("Alerts",key ,value);
                    producer.send(record2);
                } else {
                    ProducerRecord<String, String> record3 = new ProducerRecord<>("Sample",key ,value);
                    producer.send(record3);
                }


            }
            logger.info("Data retrieval and transmission to Kafka Producer completed successfully.");
            System.out.println("Initiating data extraction from MYSQL database...");
            System.out.println("Data extraction from MYSQL database has been completed successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            producer.close();
            System.out.println("Data has been published to the designated Kafka topics.");
        }
    }
}
